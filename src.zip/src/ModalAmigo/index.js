import React from "react";

function ModalAmigo() {
    
    return(
        <h1>Modal Amigo</h1>
    )
}

export default ModalAmigo;